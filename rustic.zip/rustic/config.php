<?php
require_once('stripe-php/init.php');

$stripe = array(
  "secret_key"      => "sk_test_ZBXmGlwfNa1ujdbELKTratpw",
  "publishable_key" => "pk_test_X93kosMIU6E41VMuXXz5FLMJ"
);

\Stripe\Stripe::setApiKey($stripe['secret_key']);
?>
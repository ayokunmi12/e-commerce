<?php

session_start();
include('dbconnect.php');


if(isset($_SESSION['login'])){
	//echo "The User is logged in! LOGIN SUCCESSFUL!";
	?><!-- <script>alert("The User is logged in! LOGIN SUCCESSFUL!");</script> --><?php
} else {
	//echo "The user is NOT logged in!";
	?><!-- <script>alert("The User is NOT logged in!");</script> --><?php
}



?>

<html>
<head>
	<title>rustic | Romanian traditional clothes</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript" src="jquery-3.3.1.min.js"></script>
	<script type="text/javascript">
		function showSubmenu(){
			$("#submenu").toggle();
		}

		function showMenuLogin(){
			$("#submenuLogin").toggle();
			// alert("Please enter username");
			
		}

		// (function(){
		//     $("#submenuLogin").css("display", "none");
		// })();

		// function showMenuLogin(){
		// 	alert("0 euro");
		// 	console.log("No error");

		// 	var z=document.getElementById('div11');
		// 	z.style.setProperty("background", "#FF0000", "");
		// }
	</script>
</head>
<body>

	<div id="wrapper">

		<?php include('header.php'); ?>

		<div id="div2">
			<?php include('divmenu.php'); ?>
			<div id="div22" style="padding-left: 0px;">
				<div id="ima"></div>
				<div id="presentation"> Romanian traditional clothes<br> are a milestone proof of successful use of organic linen products and hemp in clothing! There is no artistic side: flowers and decorations are made in cotton, wool and dyed with 100% natural, ecological and biodegradable colors</div>
				<!-- <div id="presentation" class="sideDiv22"> Hainele tarditionale romanesti sunt o dovada milenara a utilizarii cu succes al produslor biologice din in si canepa in vestimentatie! Nu lipseste nici partea artistica: florile si decoratiile sunt realizate in bumbac, lana si vopsite cu culori 100% naturale, ecologice si biodegrdabile</div> -->

			</div>
		</div>

		<div id="div3">Romanian traditional clothes!</div>
	</div>
</body>
</html>
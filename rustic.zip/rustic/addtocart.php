<?php

session_start();
include('dbconnect.php');

if(isset($_GET['id'])){
  $id = $_GET['id'];
} else {
  echo "Product id not set";
}

// if($_SESSION['cartitems'] == "active"){
// 	$_SESSION['cartitems'] = $_SESSION['cartitems']."xxx".$id;
// } else {
// 	$_SESSION['cart'] = "active";
// 	$_SESSION['cartitems'] = $id;
// }

if(isset($_SESSION['cartitems'])){
	$_SESSION['cartitems'] = $_SESSION['cartitems'].".".$id;
} else {
	$_SESSION['cartitems'] = $id;
}


// reduce stock amount after every purchase

$updatequery = mysqli_query($con, "SELECT * FROM products WHERE id ='$id'");
$updaterow = mysqli_fetch_assoc($updatequery);
$newvalue = $updaterow['stock'] - 1;

$newquery = mysqli_query($con, "UPDATE products SET stock='$newvalue' WHERE id='$id'");



// update cart total price

if(isset($_SESSION['cartitems'])){
	
	$parts = explode('.', $_SESSION['cartitems']);
	$size = sizeof($parts);
}

$total_price = 0;

for($i = 0; $i < $size; $i ++){

	
	$itemid = $parts[$i];

	$request1 = mysqli_query($con, "SELECT * FROM products WHERE id='$itemid'");
	$rows1 = mysqli_fetch_assoc($request1);

	$total_price = $total_price + $rows1['price'];

}

$_SESSION['total_price'] = $total_price;




 
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>

<?php
  session_start();
  require_once('./config.php');

  $token  = $_POST['stripeToken'];
  $email  = $_POST['stripeEmail'];

  $useremail = $_POST['email'];
  $amount = $_POST['totamount'];

  $customer = \Stripe\Customer::create(array(
      'email' => $email,
      'source'  => $token
  ));

  $charge = \Stripe\Charge::create(array(
      'customer' => $customer->id,
      'amount'   => $amount,
      'currency' => 'eur'
  ));

  $amount = $amount / 100;

  unset($_SESSION['cartitems']);
  unset($_SESSION['total_price']); 
?>

<!DOCTYPE html>
<html>
<head>
  <title>rustic | Romanian traditional clothes</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script type="text/javascript" src="jquery-3.3.1.min.js"></script>
  <script type="text/javascript">
    function showSubmenu(){
      $("#submenu").toggle();
    }

    function showMenuLogin(){
      $("#submenuLogin").toggle();
      // alert("Please enter username");
      
    }

    // function showMenuLogin(){
    //  alert("0 euro");
    //  console.log("No error");

    //  var z=document.getElementById('div11');
    //  z.style.setProperty("background", "#FF0000", "");
    // }
  </script>
</head>
<body>

  <div id="wrapper">

    <?php include('header.php'); ?>

    <div id="div2">
     
      <?php include('divmenu.php'); ?>
   
      <div id="div22" style="">


            <br/>
            <br/>
            <?php echo '<h2>Successfully charged for EUR '.$amount.' to customer: '.$useremail.'!</h2>'; ?>
            <br/><br/>

            <p>Go back to home page:  <a href="index.php"><div id="homebutton">Home</div></a></p>
      </div>
  </div>

  <div id="div3">Romanian traditional clothes!</div>
</body>
</html>
<div id="div1">
	<div id="div11">
		<div id="title">Rustic</div><br>
		<div id="subtitle">Romanian traditional clothes</div>
	</div>
	<div id="div12">
		<div id="search" class="side">Define your styles in Romainan</div>
		<div id="searchIcon" class="side"></div>
		


		<?php
		if(isset($_SESSION['login'])){

		} else {
		?>
		<div id="login" class="side" onclick="showMenuLogin()">Log In</div>
		<div id="submenuLogin" class="side"> 
			<a href="signin.php"> <div class="loginButton" >Sign in</div></a>
			<a href="registration.php"> <div class="loginButton" >Registration</div></a>
		</div>
		<?php
		}
		?>

		<div style="float: right;">

		<div id="money" class="side" >EUR <?php if(isset($_SESSION['total_price'])){ echo $_SESSION['total_price']; } else { echo "0";} ?></div>
		<a href="cart.php"><div id="cart" class="side"></div></a>
		</div>
	</div>	
	<div id="div13">
		<?php
			if(isset($_SESSION['login'])){

				$email = $_SESSION['login'];
				echo "Welcome, ".$email." | <a href='logout.php'>LOGOUT</a>";
			}
		?>
		</div>
</div>
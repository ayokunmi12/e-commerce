<?php

$host = 'localhost';
$user = "root";
$password = "root";
$db = "rustic";

$con = mysqli_connect($host, $user, $password, $db);

?>
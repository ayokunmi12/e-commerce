<div id="div21">
	<a href="index.php"> <div class="button">Home</div> </a>
	<div class="button" onclick="showSubmenu()">Products</div>
		<div id="submenu">
			<a href="men.php"><div class="category" onclick="onclickCategory"> Men</div></a>
			<a href="women.php"><div class="category" onclick="onclickCategory"> Women</div></a>
			<a href="children.php"><div class="category" onclick="onclickCategory"> Children</div></a>
		</div>
	<a href="contact.php"> <div class="button">Contact</div></a>
	<div id="map"></div>
</div>
<?php 

session_start();
include('dbconnect.php');

if(isset($_GET['id'])){
  $id = $_GET['id'];
} else {
  echo "Product id not set";
}

if(isset($_SESSION['cartitems'])){
  // echo "cart: ".$_SESSION['cartitems'];
}

?>


<html>
<head>
  <title>rustic | Romanian traditional clothes</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script type="text/javascript" src="jquery-3.3.1.min.js"></script>
  <script type="text/javascript">
    function showSubmenu(){
      $("#submenu").toggle();
    }

    function showMenuLogin(){
      $("#submenuLogin").toggle();
      // alert("Please enter username");
      
    }

    // function showMenuLogin(){
    //  alert("0 euro");
    //  console.log("No error");

    //  var z=document.getElementById('div11');
    //  z.style.setProperty("background", "#FF0000", "");
    // }
  </script>
</head>
<body>

  <div id="wrapper">

    <?php include('header.php'); ?>

    <div id="div2">
      <?php include('divmenu.php'); ?>
      <div id="div22" style="overflow-y: hidden;">

        <?php

          $result = mysqli_query($con, "SELECT * FROM products WHERE id='$id'");
          $row = mysqli_fetch_assoc($result);
        ?>



        <div id="div221"> <img src='images/<?php echo $row['category']; ?>/<?php echo $row['image']; ?>' style="width: 100%; height: 100%;"/></div>
        <div id="div222">
          <div id="name"><?php echo $row['name'] ?></div>
          <div id="description">Description: <?php echo $row['description']; ?></div>
          <div id="price">Price: <?php echo $row['price']; ?> Euro</div>

          <div id="itemInStock">Items in stock: <?php echo $row['stock']; ?></div>
          <!-- <div id="size">search size</div> -->
          <div></div>
          <a href="addtocart.php?id=<?php echo $id; ?>"><div id="add">Add to cart</div></a><br>
          <a href="cart.php"><div id="add">Checkout</div></a><br>

        


          <!-- // STRIPE PAYMENT BLOCK -->

            <?php require_once('./config.php'); ?>

            <!-- <form action="charge.php" method="post">


            <input type="hidden" name="email" value="jdoe@zyzzyu.com">
              <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                      data-key="<?php echo $stripe['publishable_key']; ?>"
                      data-description="Access for a year"
                      data-amount="5000"
                      data-locale="auto"></script>
            </form> -->

            <!-- // STRIPE PAYMENT BLOCK -->

         
        </div>      
      </div>
  </div>

  <div id="div3">Romanian traditional clothes!</div>
</body>
</html>
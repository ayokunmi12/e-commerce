<?php

session_start();
include('dbconnect.php');

if(isset($_GET['id'])){
  	$deleteid = $_GET['id'];

	// add stock amount after every delete from cart
	$updatequery = mysqli_query($con, "SELECT * FROM products WHERE id ='$deleteid'");
	$updaterow = mysqli_fetch_assoc($updatequery);
	$newvalue = $updaterow['stock'] + 1;

	$newquery = mysqli_query($con, "UPDATE products SET stock='$newvalue' WHERE id='$deleteid'");


} else {
  echo "Product id not set";
}


if(isset($_SESSION['cartitems'])){
	
	$parts = explode('.', $_SESSION['cartitems']);
	$size = sizeof($parts);
}

unset($_SESSION['cartitems']);

for($i = 0; $i < $size; $i ++){
	$itemid = $parts[$i];

	if($itemid == $deleteid){

	} else {
		if(isset($_SESSION['cartitems'])){
			$_SESSION['cartitems'] = $_SESSION['cartitems'].".".$itemid;
		} else {
			$_SESSION['cartitems'] = $itemid;
		}
	}

}


header('Location: ' . $_SERVER['HTTP_REFERER']);
?>

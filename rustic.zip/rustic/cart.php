<?php

session_start();
include('dbconnect.php');

if(isset($_SESSION['cartitems'])){
	
	$parts = explode('.', $_SESSION['cartitems']);
	$size = sizeof($parts);
}

$total_price = 0;

for($i = 0; $i < $size; $i ++){

	
	$itemid = $parts[$i];

	$request1 = mysqli_query($con, "SELECT * FROM products WHERE id='$itemid'");
	$rows1 = mysqli_fetch_assoc($request1);

	$total_price = $total_price + $rows1['price'];

}

$_SESSION['total_price'] = $total_price;



?>

<html>
<head>
	<title>rustic | Romanian traditional clothes</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<script type="text/javascript" src="jquery-3.3.1.min.js"></script>
	<script type="text/javascript">
		function showSubmenu(){
			$("#submenu").toggle();
		}

		function showMenuLogin(){
			$("#submenuLogin").toggle();
			// alert("Please enter username");
			
		}

		// (function(){
		//     $("#submenuLogin").css("display", "none");
		// })();

		// function showMenuLogin(){
		// 	alert("0 euro");
		// 	console.log("No error");

		// 	var z=document.getElementById('div11');
		// 	z.style.setProperty("background", "#FF0000", "");
		// }
	</script>
</head>
<body>

	<div id="wrapper">

		<?php include('header.php'); ?>


		<div id="div2">
				
			<?php include('divmenu.php'); ?>
		
			<div id="div22">
				<?php

					echo "<br/><h3>Items in cart:</h3>";
					for($i = 0; $i < $size; $i ++){

						
						$itemid = $parts[$i];
						echo "<br/>";


						$request = mysqli_query($con, "SELECT * FROM products WHERE id='$itemid'");
						$rows = mysqli_fetch_assoc($request);

						?>

						<div id="citem">
							<div id="cphoto" style="background: url(images/<?php echo $rows['category']; ?>/<?php echo $rows['image']; ?>); background-size: cover;"></div>
							<div id="cdesc"><p style="margin: 10px;"><?php echo $rows['name']." - ".$rows['description']; ?></p></div>
							<div id="cprice">
								<div id="pricebar">EUR <?php echo $rows['price']; ?></div>
								<a href="deletefromcart.php?id=<?php echo $rows['id']; ?>"><div id="deletebutton" >Delete</div></a>
							</div>
						</div>


						<?php

					}


					
				?>


				<div style="width: 500px; float: right; margin: 10px 100px; text-align: right;">

					<?php echo "<div id='finalprice'>Total Price: EUR ".$total_price."</div>"; ?>
					<?php require_once('./config.php'); ?>
					<?php
			        	if(isset($_SESSION['login'])){
			        		$email =  $_SESSION['login'];

			        	?>
			        		
					        <form action="charge.php" method="post">
					        	<!-- add $email
					        	add $total_price
					        	then add the charge to database -->
					        <input type="hidden" name="email" value="<?php echo $email; ?>">
					        <input type="hidden" name="totamount" value="<?php echo $total_price.'00'; ?>">

					          <script src="https://checkout.stripe.com/checkout.js" class="stripe-button"
					                  data-key="<?php echo $stripe['publishable_key']; ?>"
					                  data-description="Rustic Online Store"
					                  data-currency="eur"
					                  data-amount="<?php echo $total_price.'00'; ?>"
					                  data-locale="auto"></script>
					        </form>
			        	<?php
			        	} else {
			        	?>
			        		<p>Please log in or register to purchase!</p><br/>
			        		<a href="signin.php"><div id="deflect">Login to purchase</div></a>
			        		<br/><br/><br/>

			        		<div style="width: 400px; height: 100px; float: right;"><p>Don't have an account?<a href="registration.php"><div>Register here</div></a></p></div>

			        	<?php
			        	}
			        ?>



		    	</div>

		        <br/><br/>

			</div>
		</div>

		<div id="div3">Romanian traditional clothes!</div>
	</div>
</body>
</html>
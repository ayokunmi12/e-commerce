<?php

session_start();
include('dbconnect.php');

if(isset($_SESSION['cartitems'])){
  
  $parts = explode('.', $_SESSION['cartitems']);
  $size = sizeof($parts);
}

$total_price = 0;

for($i = 0; $i < $size; $i ++){

  
  $itemid = $parts[$i];

  $request1 = mysqli_query($con, "SELECT * FROM products WHERE id='$itemid'");
  $rows1 = mysqli_fetch_assoc($request1);

  $total_price = $total_price + $rows1['price'];

}

$_SESSION['total_price'] = $total_price;

?>


<!DOCTYPE html>
<html>
<head>
  <title>rustic | Romanian traditional clothes</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script type="text/javascript" src="jquery-3.3.1.min.js"></script>
  <script type="text/javascript">
    function showSubmenu(){
      $("#submenu").toggle();
    }

    function showMenuLogin(){
      $("#submenuLogin").toggle();
      // alert("Please enter username");
      
    }

    // function showMenuLogin(){
    //  alert("0 euro");
    //  console.log("No error");

    //  var z=document.getElementById('div11');
    //  z.style.setProperty("background", "#FF0000", "");
    // }
  </script>
</head>
<body>

  <div id="wrapper">

    <?php include('header.php'); ?>

    <div id="div2">
     
      <?php include('divmenu.php'); ?>
   
      <div id="div22" style="">
        <?php
          $men = "men";
          $result = mysqli_query($con, "SELECT * FROM products WHERE category='$men'");

          while($row = mysqli_fetch_assoc($result)){

            ?>
              <div id="divMen">
                <div id="photoMen" style="background: url(images/men/<?php echo $row['image']; ?>); background-size: cover;"></div>
                <div id="shortDescription1"><?php echo $row['name']; ?></div>
                <div id="moneyPhoto1"><?php echo $row['price']; ?></div>
                <div id="euro1">EURO</div> 
                <a href="more1Men.php?id=<?php echo $row['id']; ?>"><div id="more1Men">More...</div></a>
              </div> 
            <?php

          }
        ?>
      </div>
  </div>

  <div id="div3">Romanian traditional clothes!</div>
</body>
</html>
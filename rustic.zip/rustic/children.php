<?php

session_start();
include('dbconnect.php');

if(isset($_SESSION['cartitems'])){
  
  $parts = explode('.', $_SESSION['cartitems']);
  $size = sizeof($parts);
}

$total_price = 0;

for($i = 0; $i < $size; $i ++){

  
  $itemid = $parts[$i];

  $request1 = mysqli_query($con, "SELECT * FROM products WHERE id='$itemid'");
  $rows1 = mysqli_fetch_assoc($request1);

  $total_price = $total_price + $rows1['price'];

}

$_SESSION['total_price'] = $total_price;

?>


<!DOCTYPE html>
<html>
<head>
  <title>rustic | Romanian traditional clothes</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script type="text/javascript" src="jquery-3.3.1.min.js"></script>
  <script type="text/javascript">
    function showSubmenu(){
      $("#submenu").toggle();
    }

    function showMenuLogin(){
      $("#submenuLogin").toggle();
      // alert("Please enter username");
      
    }

    // function showMenuLogin(){
    //  alert("0 euro");
    //  console.log("No error");

    //  var z=document.getElementById('div11');
    //  z.style.setProperty("background", "#FF0000", "");
    // }
  </script>
</head>
<body>

  <div id="wrapper">

    <?php include('header.php'); ?>

    <div id="div2">
      <div id="div21">
        <a href="index.php"> <div class="button">Home</div> </a>
        <div class="button" onclick="showSubmenu()">Products</div>
          <div id="submenu">
            <a href="men.php"> <div class="category" onclick="onclickCategory"> Men</div></a>
            <a href="women.php"> <div class="category" onclick="onclickCategory"> Women</div></a>
            <a href="children.php"> <div class="category" onclick="onclickCategory"> Children</div></a>
          </div>
        <a href="contact.php"> <div class="button">Contact</div></a>
        <div id="map"></div>
      </div>
      <div id="div22">

        <?php
          $children = "children";
          $result = mysqli_query($con, "SELECT * FROM products WHERE category='$children'");

          while($row = mysqli_fetch_assoc($result)){

            ?>
              <div id="divMen">
                <div id="photoMen" style="background: url(images/children/<?php echo $row['image']; ?>); background-size: cover;"></div>
                <div id="shortDescription1"><?php echo $row['name']; ?> - <?php echo $row['description']; ?></div>
                <div id="moneyPhoto1"><?php echo $row['price']; ?></div>
                <div id="euro1">EURO</div> 
                <a href="more1Men.php?id=<?php echo $row['id']; ?>"><div id="more1Men">More...</div></a>
              </div> 
            <?php

          }
        ?>


<!--          <div id="divMen">
          <div id="photoMen2"></div>
          <div id="shortDescriptio2n">Treaditional shirt Adam</div>
          <div id="moneyPhoto2">215</div>
          <div id="euro2">EURO</div> 
          <a href="more2Men.html"><div id="more2Men">More...</div></a>
        </div> 
         <div id="divMen">
          <div id="photoMen3"></div>
          <div id="shortDescription3">Treaditional shirt Adam</div>
          <div id="moneyPhoto3">215</div>
          <div id="euro3">EURO</div>
          <a href="more3Men.html"><div id="more3Men">More...</div></a> 
        </div>  -->
      </div>
  </div>

  <div id="div3">Romanian traditional clothes!</div>
</body>
</html>
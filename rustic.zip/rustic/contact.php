<?php

session_start();
include('dbconnect.php');

  if (isset($_GET['contact'])){

  $firstname = $_GET['firstname'];
  $lastname = $_GET['lastname'];
  $email = $_GET['email'];
  $message = $_GET['message'];

  $result = mysqli_query($con, "INSERT INTO contact (firstname, lastname, email, message) VALUES('$firstname', '$lastname', '$email', '$message')");

  if($result){
    ?><script>alert("Your message was sent successfully!");</script><?php
  }

}



// set  total price

if(isset($_SESSION['cartitems'])){
  
  $parts = explode('.', $_SESSION['cartitems']);
  $size = sizeof($parts);
}

$total_price = 0;

for($i = 0; $i < $size; $i ++){

  
  $itemid = $parts[$i];

  $request1 = mysqli_query($con, "SELECT * FROM products WHERE id='$itemid'");
  $rows1 = mysqli_fetch_assoc($request1);

  $total_price = $total_price + $rows1['price'];

}

$_SESSION['total_price'] = $total_price;



?>



<!DOCTYPE html>
<html>
<head>
  <title>rustic | Romanian traditional clothes</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script type="text/javascript" src="jquery-3.3.1.min.js"></script>
  <script type="text/javascript">
    function showSubmenu(){
      $("#submenu").toggle();
    }

    function showMenuLogin(){
      $("#submenuLogin").toggle();
      // alert("Please enter username");
      
    }

    // function showMenuLogin(){
    //  alert("0 euro");
    //  console.log("No error");

    //  var z=document.getElementById('div11');
    //  z.style.setProperty("background", "#FF0000", "");
    // }
  </script>
</head>
<body>

  <div id="wrapper">
 
    <?php include('header.php'); ?>
   
    <div id="div2">
   
      <?php include('divmenu.php'); ?>
      
      <div id="div22">
          <div id="singin">Contact</div> 
          <div style="width: 500px; margin: 0px auto; border: 1px solid grey; padding: 20px 10px; background: white;">
             <form action="contact.php" method="GET" autocomplete>
                  <div class="labels"><label>First Name:* </label> <input type="text" name="firstname" placeholder="Enter your first name" required/>  </div>
                  <br><div class="labels"><label>Last Name:* </label> <input type="text" name="lastname" placeholder="Enter last name" required/>  </div><br/>
                  <br><div class="labels"><label>Email:*     </label><input type="email" name="email" placeholder="Enter your email" required/></div> <br/>
                  <div class="labels"><label>Message:* </label> <input type="text" name="message" placeholder="Enter your message" required/>  </div>

                   <br/><br/>
                 <input id="registrationButton" type="submit" name="contact">
            </form>
          </div>
      </div>
    </div>

  <div id="div3">Romanian traditional clothes!</div>
</body>
</html>